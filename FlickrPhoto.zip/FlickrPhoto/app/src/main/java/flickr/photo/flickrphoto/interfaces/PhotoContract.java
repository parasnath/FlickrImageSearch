package flickr.photo.flickrphoto.interfaces;

import android.widget.ImageView;

import flickr.photo.flickrphoto.models.Photos;
import flickr.photo.flickrphoto.models.Size;

public interface PhotoContract {

    interface View extends BaseView<Presenter> {

        void showProgress(final boolean show);

        void showEmptyView(final boolean show);

        void showFullScreenImage(final Size image, final String photoTitle);

        void showError(final String message);

        void populateList(final Photos photos);

        void appendList(final Photos photos);
    }

    interface Presenter extends BasePresenter {

        void searchPhotosByTag(final String tag);

        void searchPhotosByTag(final String tag, final int page);

        void getPhotoSizeList(final String photoId, final String photoTitle);

        void getImageForView(String photoId, String photoTitle, ImageView imageView);

        void showProgress(final boolean show);
    }
}
