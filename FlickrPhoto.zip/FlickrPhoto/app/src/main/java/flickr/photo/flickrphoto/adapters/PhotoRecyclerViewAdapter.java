package flickr.photo.flickrphoto.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import flickr.photo.flickrphoto.R;
import flickr.photo.flickrphoto.fragments.PhotoFragment;
import flickr.photo.flickrphoto.models.PhotoList;
import flickr.photo.flickrphoto.models.Photos;


public class PhotoRecyclerViewAdapter extends RecyclerView.Adapter<PhotoRecyclerViewAdapter.ViewHolder> {

    private final Photos mPhotos;
    private final PhotoFragment.OnPhotoInteractionListener mListener;

    public PhotoRecyclerViewAdapter(Photos photos, PhotoFragment.OnPhotoInteractionListener listener) {
        mPhotos = photos;
        mListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_photo_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.mPhotoList = mPhotos.getPhotoList().get(position);
        mListener.onPhotoBind(holder.mPhotoList.getId(), holder.mPhotoList.getTitle(), holder.mContentView);
    }

    @Override
    public int getItemCount() {
        return mPhotos.getPhotoList().size();
    }

    public Photos getAllItems() {
        return mPhotos;
    }

    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        final View mView;
        final ImageView mContentView;
        PhotoList mPhotoList;

        ViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
            mContentView = itemView.findViewById(R.id.content);
            itemView.setOnClickListener(this);
        }

        @NonNull
        @Override
        public String toString() {
            return super.toString() + " '" + mPhotoList.getTitle() + "'";
        }

        @Override
        public void onClick(View v) {
            if (null != mListener) {
                mListener.onPhotoSelected(mPhotoList);
            }
        }
    }
}
