package flickr.photo.flickrphoto.interfaces;

import java.util.Map;

import flickr.photo.flickrphoto.models.Photos;
import flickr.photo.flickrphoto.models.Size;

public interface PhotoDataSource {

    void getPhotoListByTag(String tag, int page, SearchResultCallback searchResultCallback);

    void getPhotoSizes(String photoId, GetSizesCallback getSizesCallback);

    interface SearchResultCallback {

        void onSearchResultSuccess(Photos photos);

        void onSearchFail(String errorMessage);

        void onError(String errorMessage);
    }

    interface GetSizesCallback {

        void onRequestSuccess(Map<String, Size> photoSizes);

        void onSearchFail(String errorMessage);

        void onError(String errorMessage);
    }
}
