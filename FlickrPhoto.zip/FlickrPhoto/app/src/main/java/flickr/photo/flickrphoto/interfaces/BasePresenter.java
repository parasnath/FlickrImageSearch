package flickr.photo.flickrphoto.interfaces;

public interface BasePresenter {

    void start();

}
