package flickr.photo.flickrphoto.network;

import flickr.photo.flickrphoto.models.PhotoDetails;
import flickr.photo.flickrphoto.models.SearchResultPage;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface RestInterface {

    @GET("/services/rest/?method=flickr.photos.search&format=json&nojsoncallback=1")
    Call<SearchResultPage> getSearchResults(@Query("api_key") String apiKey, @Query("tags") String tag, @Query("page") int page);

    @GET("/services/rest/?method=flickr.photos.getSizes&format=json&nojsoncallback=1")
    Call<PhotoDetails> getImageSizes(@Query("api_key") String apiKey, @Query("photo_id") String photoId);
}
